========================================================================
       KONSOLENANWENDUNG : Light_Win32 Demo Ver.1.1 
       (c) 2002-2003 PEAK-System Technik GmbH
       www.peak-system.com
========================================================================


Diese PCAN-Light Win32 Demo-Anwendung ist zum Verst�ndniss der 
PEAK-PCAN-Light API geschrieben worden.

Sie erlaubt das dynamische Laden der entsprechenden DLL.

Um eine andere Hardware zu verwenden oder Parameter anzupassen (non PNP HW)

im Kopf der CPP-Datei die entsprechenden Parameter �ndern.

Bsp. f�r PCAN-Donglemit 0x378 und Int 7:


#define CANDONGLE
//#define CANDONGLEPRO
//#define CANUSB
//#define CANISA
//#define CANPCI
// Fuer 2ten Kanal PCI!!
//#define TWO_CHANNEL



#ifdef CANDONGLE
 #include "dongle\PCAN_DNG.H"
 #define CAN_PORT 0x378
 #define CAN_INT 7
 #define CAN_HARDWARE "Dongle"
#endif

#ifdef CANDONGLEPRO
 #include "donglepro\PCAN_DNP.H"
 #define CAN_PORT 0x378
 #define CAN_INT 7
 #define CAN_HARDWARE "DonglePro"
#endif


#ifdef CANISA
 #include "isa\PCAN_ISA.H"
 #define CAN_PORT 0x300
 #define CAN_INT 10
 #define CAN_HARDWARE "ISA"
#endif

