// 
// Light_Win32 Demo.cpp 
//
// Version 1.1
//
//
// (c) 2002-2003 PEAK-System Technik GmbH
// Benzweg 4
// D-64293 Darmstadt
// www.peak-system.com
// info@peak-system.com
//
//
// PCAN-Light Demo File for VC++6 Windows Console Applikation
// Autor: U.Wilhelm
// last change 07.01.2003
// this part of code is NOT perfect...but it shows how to work with PCAN-Light API
//

#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <windows.h>


// Function declaration

bool GetFunctionAdress(HINSTANCE h_module);
void check_err(DWORD err,  char *txtbuff);
int LoadDLL(void);
int UnloadDLL(void);



// always select only ONE hardware !!

//#define CANDONGLE
//#define CANDONGLEPRO
#define CANUSB
//#define CANISA
//#define CANPCI
// Fuer 2ten Kanal PCI!!
//#define TWO_CHANNEL



#ifdef CANDONGLE
 #include "dongle\PCAN_DNG.H"
 #define CAN_PORT 0x378
 #define CAN_INT 7
 #define CAN_HARDWARE "Dongle"
#endif

#ifdef CANDONGLEPRO
 #include "donglepro\PCAN_DNP.H"
 #define CAN_PORT 0x378
 #define CAN_INT 7
 #define CAN_HARDWARE "DonglePro"
#endif


#ifdef CANISA
 #include "isa\PCAN_ISA.H"
 #define CAN_PORT 0x300
 #define CAN_INT 10
 #define CAN_HARDWARE "ISA"
#endif

#ifdef CANPCI
 #include "pci\PCAN_PCI.H"
// 2nd channel PCI !!
#ifdef TWO_CHANNEL
 #define CAN_HARDWARE "PCI 2nd Chanel"
#else
 #define CAN_HARDWARE "PCI 1st Chanel"
#endif
 #define CAN_INT 0
 #define CAN_PORT 0
 #define PNP
#endif

#ifdef CANUSB
 #include "usb\PCAN_USB.H"
 #define CAN_HARDWARE "USB"
 #define CAN_INT -1
 #define CAN_PORT -1
 #define PNP
#endif


unsigned int g_MsgCount =0;
HINSTANCE g_i_DLL;

#ifdef CANDONGLE
 char g_LibFileName[] = "dongle\\PCAN_DNG.DLL";
#endif

#ifdef CANDONGLEPRO
 char g_LibFileName[] = "donglepro\\PCAN_DNP.DLL";
#endif

#ifdef CANISA
 char g_LibFileName[] = "isa\\PCAN_ISA.DLL";
#endif

#ifdef CANPCI
// Fuer 2ten Kanal !!
 #ifdef TWO_CHANNEL
  char g_LibFileName[] = "pci\\PCAN_2PCI.DLL";
 #else
  char g_LibFileName[] = "pci\\PCAN_PCI.DLL";
 #endif
#endif

#ifdef CANUSB
 char g_LibFileName[] = "usb\\PCAN_USB.DLL";
#endif


//typdef of Functions
// PNP Hardware ?
#ifdef PNP
 typedef DWORD (__stdcall *PCAN_Init)(WORD wBTR0BTR1, int CANMsgType);
#else
 typedef DWORD (__stdcall *PCAN_Init)(WORD wBTR0BTR1, int CANMsgType, int CANHwType, DWORD IO_Port, WORD Interupt);
#endif

typedef DWORD (__stdcall *PCAN_Close)();
typedef DWORD (__stdcall *PCAN_Status)();
typedef DWORD (__stdcall *PCAN_Write)(TPCANMsg* pMsgBuff);
typedef DWORD (__stdcall *PCAN_Read)(TPCANMsg* pMsgBuff);
typedef DWORD (__stdcall *PCAN_VersionInfo)(LPSTR lpversioninfo);

//declaration
PCAN_Init g_CAN_Init;
PCAN_Close g_CAN_Close;
PCAN_Status g_CAN_Status;
PCAN_Write  g_CAN_Write;
PCAN_Read g_CAN_Read;
PCAN_VersionInfo g_CAN_VersionInfo;


//
// main entry
// Parameter: none
// ret value: 0 if OK 
//


int main(int argc, char* argv[])
{
	int ret;
	char c;
	char buffer[255];
	char buffer2[10];
	
	// CAN_Message
	TPCANMsg myMsg;
	
	//Stop Flag
	int g_stop = false;

	// Tick counter
	DWORD g_tick;

	printf("\t\tPCAN_Light Demo\n");
	printf("use dynamic load of DLL .. so one Source  .. every HW  :-)\n\n");
	printf("(c) 2002 by PEAK-System Technik GmbH Darmstadt\n");
	printf("contact: info@peak-system.com or +49 6151 81 73 20\n\n");
	printf("press <E> or <ESC> to end\n");
	printf("press <S> to send Msg ID:0x100 LEN:2 DATA0:0x010 DATA1:0x020\n");
	printf("if CAN-Msg are received they will display !\n\n");

	//Load DLL and get Proc Adress of used function ... depend on select HW Type !
	ret = LoadDLL();
	if(ret!=0)
	{
		return 1;
	}
	printf("INFO: DLL loaded\n");


	// open CAN Port
	if(g_CAN_Init !=NULL) // check if function pointer is vallid
	{
		#ifdef CANDONGLE
		// init PCAN-Dongle in MUX mode Port 0x378 and Interruot 7
		ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST, HW_DONGLE_SJA, CAN_PORT, CAN_INT);
		#endif

		#ifdef CANDONGLEPRO
		// init PCAN-DonglePro in MUX mode Port 0x378 and Interruot 7
		ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST, HW_DONGLE_PRO, CAN_PORT, CAN_INT);
		#endif

		#ifdef CANISA
		// init PCAN-ISA
		ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST, HW_ISA,  CAN_PORT, CAN_INT);
		#endif

		#ifdef CANPCI
		// init PCAN-PCI
		ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST);
		#endif

		#ifdef CANUSB
		// init PCAN-USB
		ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST);
		#endif
		
		
		check_err(ret, buffer);
		printf("CAN_Init %s\n",buffer);
		if(ret != CAN_ERR_OK)
		{
			g_stop = true;
		}
		else
		{
			ret=g_CAN_VersionInfo(buffer);
			if(ret == 0)
				printf("\nDriver Information:\n %s\n\n",buffer);
		}
	}

	// Init tick counter
	g_tick = GetTickCount();
	
	// main loop
	do{
		// Now check what to do....
		if(_kbhit())
		{
			c=_getch();
			switch(c)
			{
				case 'e':// if eE is pressed ... set stop flag
				case 'E':
				case  27:// ESC pressed 
					g_stop = true;
				break;

				case 's': // if sS is pressed ....send CAN Msg
				case 'S':
					printf("send CAN-DATA ID:0x100 LEN:2 Data:0x010 0x020\n");
					if(g_CAN_Write !=NULL) // function pointer vallid
					{
						myMsg.ID = 0x100;
						myMsg.MSGTYPE = 0;
						myMsg.LEN = 2;
						myMsg.DATA[0] = 0x010;
						myMsg.DATA[1] = 0x020;
						ret=g_CAN_Write(&myMsg);
						check_err(ret, buffer);
						printf("CAN_Send %s\n",buffer);
					 }
				break;
			}
		}
		
		// every second we read the status !
		if(GetTickCount()-g_tick > 1000) //1000 ms
		{
			// get CAN-Status 
			ret = g_CAN_Status();
			if(ret != CAN_ERR_OK)
			{
				check_err(ret, buffer);
				printf("CAN_Status: %s\n",buffer);
			}
			g_tick = GetTickCount();

		}

		//check if Data in driver buffer ...if yes print out
		if(g_CAN_Read !=NULL) // vallid pointer
		{
			while ((g_CAN_Read(&myMsg) & CAN_ERR_QRCVEMPTY)==0 )//read until buffer is empty
			{
			  // check if Status ID
			  if(myMsg.MSGTYPE != 0)  // no std. msg
			  {
				check_err(myMsg.DATA[2], buffer);
				printf("CAN Status Msg: %s\n",buffer);
			  }
			  else
			  {
				printf("read CAN-DATA ID:0x%02x LEN:%d ",myMsg.ID,myMsg.LEN);
				buffer[0]='\0';
				// check how many Data information are in MSG
				for(int i=0;i<myMsg.LEN;i++)
				{
					sprintf(buffer2,"0x%03x ",myMsg.DATA[i]);
					strcat(buffer,buffer2);
				}
				printf("Data:%s\n",buffer);
			  }
			}
		}
		

	}while(!g_stop);  // loop until stop flag is set
	

	// close CAN Port
	ret=g_CAN_Close();
	check_err(ret, buffer);
	printf("CAN_Close %s\n",buffer);	
	// unload DLL
	ret = UnloadDLL();
	if(ret!=0)
	{
		return 1;
	}
	printf("INFO: DLL unloaded\n");
	printf("Programm stoped..\n");
	_kbhit();

	return 0;
}


/*
							Needed functions......
 */


//
// Function: Load DLL
// Parameter: none
// ret value: 0 if OK, -1 if DLL not found or can not open, -2 if function pointer not found
//
// load the DLL and get function pointers
//


int LoadDLL()
{
	if(g_i_DLL==NULL)
	{
		g_i_DLL = LoadLibrary(g_LibFileName);
		if(g_i_DLL == NULL)
		{
			printf("ERROR: can not load DLL\n");
			return -1;
		}	
		else
		{
			printf("DLL Handle: 0x%x\n",g_i_DLL);
			if(GetFunctionAdress( g_i_DLL )==true)
			{
				printf("DynaLoad for PCAN_%s port: 0x%x int: %d\n",CAN_HARDWARE,CAN_PORT,CAN_INT);
		
			}
			else
			{
				printf("ERROR: can not load Function Adress\n");
				return -2;
			}
		}
	}
	return 0;
}


//
// Function: Unload DLL
// Parameter: none
// ret value: 0 if OK 
//
// unload the DLL and free all pointers
//

int UnloadDLL()
{
 if(g_i_DLL)
 {
  FreeLibrary(g_i_DLL);
  g_i_DLL = NULL;
  g_CAN_Init=NULL;
  g_CAN_Close=NULL;
  g_CAN_Status=NULL;
  g_CAN_Write=NULL;
  g_CAN_Read=NULL;
  g_CAN_VersionInfo=NULL;
  return 0;
 }
 return -1;
}


//
// Function: GetFunctionAdress
// Parameter: instance of DLL
// ret value: true if OK false if pointer not vallid
//
// load the function pointer from the DLL spec. by handle
//



bool GetFunctionAdress(HINSTANCE h_module)
{
  //Lade alle Funktionen
  if(h_module == NULL)
   return false;

  g_CAN_Init = (PCAN_Init) GetProcAddress(h_module, "CAN_Init");
  if(g_CAN_Init == NULL)
   return false;

  g_CAN_Close = (PCAN_Close) GetProcAddress(h_module, "CAN_Close");
  if(g_CAN_Close == NULL)
   return false;

  g_CAN_Status = (PCAN_Status) GetProcAddress(h_module, "CAN_Status");
  if(g_CAN_Status == NULL)
   return false;

  g_CAN_Write = (PCAN_Write) GetProcAddress(h_module, "CAN_Write");
  if(g_CAN_Write == NULL)
   return false;

  g_CAN_Read = (PCAN_Read) GetProcAddress(h_module, "CAN_Read");
  if(g_CAN_Read == NULL)
   return false;

  g_CAN_VersionInfo = (PCAN_VersionInfo) GetProcAddress(h_module, "CAN_VersionInfo");
  if(g_CAN_VersionInfo == NULL)
   return false;

  return true;
}


//
// Function: check_err
// Parameter: erroro code, pointer to text buffer
// ret value: none
//
// translate PCAN-Light error code (numeric) to text information
//


void check_err(DWORD err,  char *txtbuff)
{
	#define CAN_ERR_HWINUSE   0x0400  // Hardware ist von Netz belegt
	#define CAN_ERR_NETINUSE  0x0800  // an Netz ist Client angeschlossen
	#define CAN_ERR_ILLHW     0x1400  // Hardwarehandle war ungueltig
	#define CAN_ERR_ILLNET    0x1800  // Netzhandle war ungueltig
	#define CAN_ERR_ILLCLIENT 0x1C00  // Clienthandle war ungueltig

        strcpy(txtbuff, "Error: ") ;
        if ( err == CAN_ERR_OK )        strcpy(txtbuff, "OK ") ;
        if ( err & CAN_ERR_XMTFULL )    strcat(txtbuff, "XMTFULL ") ;
        if ( err & CAN_ERR_OVERRUN )    strcat(txtbuff, "OVERRUN ") ;
        if ( err & CAN_ERR_BUSLIGHT )   strcat(txtbuff, "BUSLIGHT ") ;
        if ( err & CAN_ERR_BUSHEAVY )   strcat(txtbuff, "BUSHEAVY ") ;
        if ( err & CAN_ERR_BUSOFF )     strcat(txtbuff, "BUSOFF ") ;
        if ( err & CAN_ERR_QRCVEMPTY )  strcat(txtbuff, "QRCVEMPTY ") ;
        if ( err & CAN_ERR_QOVERRUN )   strcat(txtbuff, "QOVERRUN ") ;
        if ( err & CAN_ERR_QXMTFULL )   strcat(txtbuff, "QXMTFULL ") ;
        if ( err & CAN_ERR_REGTEST )    strcat(txtbuff, "REGTEST ") ;
        if ( err & CAN_ERR_NOVXD )      strcat(txtbuff, "NOVXD ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_HWINUSE ) strcat(txtbuff, "HWINUSE ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_NETINUSE ) strcat(txtbuff, "NETINUSE ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_ILLHW )strcat(txtbuff, "ILLHW ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_ILLCLIENT )strcat(txtbuff, "ILLCLIENT ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_ILLNET ) strcat(txtbuff, "ILLNET ") ;
        if ( err & CAN_ERR_RESOURCE ) strcat(txtbuff, "RESOURCE ") ;
        if ( err & CAN_ERR_ILLPARAMTYPE ) strcat(txtbuff, "ILLPARAMTYPE ") ;
        if ( err & CAN_ERR_ILLPARAMVAL ) strcat(txtbuff, "ILLPARAMVAL ") ;
        return;
 }
