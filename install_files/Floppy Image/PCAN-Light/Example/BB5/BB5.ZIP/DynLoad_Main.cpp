//---------------------------------------------------------------------------

#include <vcl.h>
#include "stdio.h"
#pragma hdrstop

// immer nur eine HW ausw�hlen !!

//#define CANDONGLE
#define CANUSB
//#define CANISA
//#define CANPCI
// Fuer 2ten Kanal PCI!!
#define TWO_CHANNEL


#ifdef CANDONGLE
 #include "PCAN_DNG.H"
 #define CAN_PORT 0x378
 #define CAN_INT 7
 #define CAN_HARDWARE "Dongle"
#endif

#ifdef CANISA
 #include "PCAN_ISA.H"
 #define CAN_PORT 0x300
 #define CAN_INT 10
 #define CAN_HARDWARE "ISA"
#endif

#ifdef CANPCI
 #include "PCAN_PCI.H"
// Fuer 2ten Kanal !!
#ifdef TWO_CHANNEL
 #define CAN_HARDWARE "PCI 2ter Kanal"
#else
 #define CAN_HARDWARE "PCI 1ter Kanal"
#endif
 #define CAN_INT 0
 #define CAN_PORT 0
 #define PNP
#endif

#ifdef CANUSB
 #include "PCAN_USB.H"
 #define CAN_HARDWARE "USB"
 #define CAN_INT -1
 #define CAN_PORT -1
 #define PNP
#endif


#include "DynLoad_Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
unsigned int g_MsgCount =0;

HINSTANCE g_i_DLL;

#ifdef CANDONGLE
 char g_LibFileName[] = "PCAN_DNG.DLL";
#endif

#ifdef CANISA
 char g_LibFileName[] = "PCAN_ISA.DLL";
#endif

#ifdef CANPCI
// Fuer 2ten Kanal !!
 #ifdef TWO_CHANNEL
  char g_LibFileName[] = "PCAN_2PCI.DLL";
 #else
  char g_LibFileName[] = "PCAN_PCI.DLL";
 #endif
#endif

#ifdef CANUSB
 char g_LibFileName[] = "PCAN_USB.DLL";
#endif


//typdef der Funktionen
#ifdef PNP
 typedef DWORD (__stdcall *PCAN_Init)(WORD wBTR0BTR1, int CANMsgType);
#else
 typedef DWORD (__stdcall *PCAN_Init)(WORD wBTR0BTR1, int CANMsgType, int CANHwType, DWORD IO_Port, WORD Interupt);
#endif

typedef DWORD (__stdcall *PCAN_Close)();
typedef DWORD (__stdcall *PCAN_Status)();
typedef DWORD (__stdcall *PCAN_Write)(TPCANMsg* pMsgBuff);
typedef DWORD (__stdcall *PCAN_Read)(TPCANMsg* pMsgBuff);
typedef DWORD (__stdcall *PCAN_VersionInfo)(LPSTR lpversioninfo);
//Nur Dongle im Moment
#ifdef CANDONGLE
 typedef DWORD (__stdcall *PCAN_SpecialFunktion)(unsigned long distributorcode, int codenumber );
#endif
//declaration
PCAN_Init g_CAN_Init;
PCAN_Close g_CAN_Close;
PCAN_Status g_CAN_Status;
PCAN_Write  g_CAN_Write;
PCAN_Read g_CAN_Read;
PCAN_VersionInfo g_CAN_VersionInfo;
#ifdef CANDONGLE
 PCAN_SpecialFunktion g_CAN_SpecialFunktion;
#endif


//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
 char buffer[255];
 //Load DLL
 if(g_i_DLL==NULL)
 {
  g_i_DLL = LoadLibrary(g_LibFileName);
  if(g_i_DLL == NULL)
   Application->MessageBox("can not load DLL","error",MB_ICONSTOP);
  else
  {
   sprintf(buffer,"0x%x",g_i_DLL);
   L_H_DNG->Caption = buffer;
   if(GetFunctionAdress( g_i_DLL )==true)
   {
    Label3->Caption = "OK";
    sprintf(buffer,"DynaLoad for PCAN_%s port: 0x%x int: %d",CAN_HARDWARE,CAN_PORT,CAN_INT);
    Form1->Caption = buffer;
   }
  }
 }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
 if(g_i_DLL)
 {
  FreeLibrary(g_i_DLL);
  g_i_DLL = NULL;
  L_H_DNG->Caption = "null";
  Label3->Caption = "null";
  Label4->Caption = "null";
  Label6->Caption = "none";
  Label10->Caption = "none";
  Label11->Caption = "none";
  Label12->Caption = "none";
  Label15->Caption = "none";
  g_CAN_Init=NULL;
  g_CAN_Close=NULL;
  g_CAN_Status=NULL;
  g_CAN_Write=NULL;
  g_CAN_Read=NULL;
  g_CAN_VersionInfo=NULL;
#ifdef CANDONGLE
  g_CAN_SpecialFunktion=NULL;
#endif
 }
}
//---------------------------------------------------------------------------


bool GetFunctionAdress(HINSTANCE h_module)
{
  //Lade alle Funktionen
  if(h_module == NULL)
   return false;

  g_CAN_Init = (PCAN_Init) GetProcAddress(h_module, "CAN_Init");
  if(g_CAN_Init == NULL)
   return false;

  g_CAN_Close = (PCAN_Close) GetProcAddress(h_module, "CAN_Close");
  if(g_CAN_Close == NULL)
   return false;

  g_CAN_Status = (PCAN_Status) GetProcAddress(h_module, "CAN_Status");
  if(g_CAN_Status == NULL)
   return false;

  g_CAN_Write = (PCAN_Write) GetProcAddress(h_module, "CAN_Write");
  if(g_CAN_Write == NULL)
   return false;

  g_CAN_Read = (PCAN_Read) GetProcAddress(h_module, "CAN_Read");
  if(g_CAN_Read == NULL)
   return false;

  g_CAN_VersionInfo = (PCAN_VersionInfo) GetProcAddress(h_module, "CAN_VersionInfo");
  if(g_CAN_VersionInfo == NULL)
   return false;

  //NUR DOngle !!
#ifdef CANDONGLE
  g_CAN_SpecialFunktion = (PCAN_SpecialFunktion) GetProcAddress(h_module, "CAN_SpecialFunktion");
  if(g_CAN_SpecialFunktion == NULL)
   return false;
#endif

  return true;
}
void __fastcall TForm1::BInitDNGClick(TObject *Sender)
{
 DWORD ret;
 char buffer[255];
 if(g_CAN_Init !=NULL)
 {
  #ifdef CANDONGLE
   // Initialisiere PCAN-Dongle im MUX mode auf Port 0x378 und Interruot 7
   ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST, HW_DONGLE_SJA, CAN_PORT, CAN_INT);
  #endif

  #ifdef CANISA
   // Initialisiere PCAN-ISA
   ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST, HW_ISA,  CAN_PORT, CAN_INT);
  #endif

  #ifdef CANPCI
   // Initialisiere PCAN-PCI
   ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST);
  #endif

  #ifdef CANUSB
   // Initialisiere PCAN-USB
   ret=g_CAN_Init(CAN_BAUD_500K, CAN_INIT_TYPE_ST);
  #endif

  Label6->Caption = ret;
  check_err(ret, buffer);
  Label14->Caption = buffer;
  ret=g_CAN_VersionInfo(buffer);
  if(ret == 0)
   Label4->Caption = buffer;
 }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::BCloseDNGClick(TObject *Sender)
{
 DWORD ret;
 char buffer[255];

 if(g_CAN_Close !=NULL)
 {
  ret=g_CAN_Close();
  Label6->Caption = ret;
  check_err(ret, buffer);
  Label14->Caption = buffer;
  Label10->Caption = "none";
  Label11->Caption = "none";
  Label12->Caption = "none";
  Label15->Caption = "none";  
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BStatusDNGClick(TObject *Sender)
{
 DWORD ret;
 char buffer[255];

 if(g_CAN_Status !=NULL)
 {
  ret=g_CAN_Status();
  Label6->Caption = ret;
  check_err(ret, buffer);
  Label14->Caption = buffer;
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
 Button2Click(Sender);
 Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
 DWORD ret;
 char buffer[255];
  
 // CAN_Message
 TPCANMsg myMsg;

 if(g_CAN_Write !=NULL)
 {
  myMsg.ID = 0x100;
  myMsg.MSGTYPE = 0;
  myMsg.LEN = 8;
  myMsg.DATA[0] = 0x01;
  myMsg.DATA[1] = 0x02;
  myMsg.DATA[2] = 0x04;
  myMsg.DATA[3] = 0x08;
  myMsg.DATA[4] = 0x10;
  myMsg.DATA[5] = 0x20;
  myMsg.DATA[6] = 0x40;
  myMsg.DATA[7] = 0x80;
  ret=g_CAN_Write(&myMsg);
  Label6->Caption = ret;
  check_err(ret, buffer);
  Label14->Caption = buffer;
 }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
 DWORD ret;
 char buffer[255];
 char buffer2[255];
 // CAN_Message
 TPCANMsg myMsg;

 if(g_CAN_Read !=NULL)
 {
  ret=g_CAN_Read(&myMsg);
  Label6->Caption = ret;
  check_err(ret, buffer);
  Label14->Caption = buffer;
  if(myMsg.ID< 0 || myMsg.ID > CAN_MAX_STANDARD_ID)
   return;
  if(myMsg.MSGTYPE!=0)
   return;
  if(ret != CAN_ERR_OK)
   return;
  g_MsgCount++;
  Label15->Caption =  g_MsgCount;
  Label10->Caption =  myMsg.ID;
  Label11->Caption =  myMsg.LEN;
  buffer[0]='\0';
  for(int i=0;i<myMsg.LEN;i++)
  {
   sprintf(buffer2,"0x%03x ",myMsg.DATA[i]);
   strcat(buffer,buffer2);
  }
  Label12->Caption =  buffer;
 }

}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
void check_err(DWORD err,  char *txtbuff)
{
#define CAN_ERR_HWINUSE   0x0400  // Hardware ist von Netz belegt
#define CAN_ERR_NETINUSE  0x0800  // an Netz ist Client angeschlossen
#define CAN_ERR_ILLHW     0x1400  // Hardwarehandle war ungueltig
#define CAN_ERR_ILLNET    0x1800  // Netzhandle war ungueltig
#define CAN_ERR_ILLCLIENT 0x1C00  // Clienthandle war ungueltig

        strcpy(txtbuff, "Error: ") ;
        if ( err == CAN_ERR_OK )        strcpy(txtbuff, "OK ") ;
        if ( err & CAN_ERR_XMTFULL )    strcat(txtbuff, "XMTFULL ") ;
        if ( err & CAN_ERR_OVERRUN )    strcat(txtbuff, "OVERRUN ") ;
        if ( err & CAN_ERR_BUSLIGHT )   strcat(txtbuff, "BUSLIGHT ") ;
        if ( err & CAN_ERR_BUSHEAVY )   strcat(txtbuff, "BUSHEAVY ") ;
        if ( err & CAN_ERR_BUSOFF )     strcat(txtbuff, "BUSOFF ") ;
        if ( err & CAN_ERR_QRCVEMPTY )  strcat(txtbuff, "QRCVEMPTY ") ;
        if ( err & CAN_ERR_QOVERRUN )   strcat(txtbuff, "QOVERRUN ") ;
        if ( err & CAN_ERR_QXMTFULL )   strcat(txtbuff, "QXMTFULL ") ;
        if ( err & CAN_ERR_REGTEST )    strcat(txtbuff, "REGTEST ") ;
        if ( err & CAN_ERR_NOVXD )      strcat(txtbuff, "NOVXD ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_HWINUSE ) strcat(txtbuff, "HWINUSE ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_NETINUSE ) strcat(txtbuff, "NETINUSE ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_ILLHW )strcat(txtbuff, "ILLHW ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_ILLCLIENT )strcat(txtbuff, "ILLCLIENT ") ;
        if ( (err & CAN_ERRMASK_ILLHANDLE) == CAN_ERR_ILLNET ) strcat(txtbuff, "ILLNET ") ;
        if ( err & CAN_ERR_RESOURCE ) strcat(txtbuff, "RESOURCE ") ;
        if ( err & CAN_ERR_ILLPARAMTYPE ) strcat(txtbuff, "ILLPARAMTYPE ") ;
        if ( err & CAN_ERR_ILLPARAMVAL ) strcat(txtbuff, "ILLPARAMVAL ") ;
        return;
 }



