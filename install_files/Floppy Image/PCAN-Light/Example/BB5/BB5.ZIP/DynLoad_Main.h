//---------------------------------------------------------------------------

#ifndef DynLoad_MainH
#define DynLoad_MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
        TButton *Button1;
        TLabel *Label1;
        TLabel *L_H_DNG;
        TButton *Button2;
        TLabel *Label2;
        TLabel *Label3;
        TButton *BInitDNG;
        TButton *BCloseDNG;
        TButton *BStatusDNG;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TButton *Button3;
        TButton *Button4;
        TButton *Button5;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label14;
        TLabel *Label13;
        TLabel *Label15;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall BInitDNGClick(TObject *Sender);
        void __fastcall BCloseDNGClick(TObject *Sender);
        void __fastcall BStatusDNGClick(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall Button5Click(TObject *Sender);
private:	// Anwender-Deklarationen
public:		// Anwender-Deklarationen
        __fastcall TForm1(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;


bool GetFunctionAdress(HINSTANCE h_module);
void check_err(DWORD err,  char *txtbuff);
//---------------------------------------------------------------------------
#endif
